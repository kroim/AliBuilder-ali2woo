<?php

function alib_import_to_list(){
 global $wpdb;
 
include('simple_html_dom.php');
 
$url = $_POST['product_url'];
$product_img = $_POST['product_img']; 
$product_id = $_POST['product_id']; 

$html = file_get_html($url);


$links = array();
foreach($html->find('h1[class="product-name"]') as $a) {
 $links[] = $a->plaintext;
}
 
 
 $title = $links[0] ;
 ///////////
 
 $var1 = array();
foreach($html->find('a[id*="sku-1"]') as $a) {
 $var1[] = $a->title;
}
 
 
 ////////////
 
  
 $var2 = array();
foreach($html->find('a[id*="sku-2"]') as $a) {
 $var2[] = $a->innertext;
}
 
 
 ////////////
 

 
 ////////////
 
 
 $shipd = array();
foreach($html->find('li[class="packaging-item"]') as $a) {
 $shipd[] = $a->innertext;
}
 


$links = array();
foreach($html->find('span[id="j-sku-price"]') as $a) {
 $links[] = $a->innertext;
}
 
$price = $links[0];

$length = count($var1);

for ($i = 0; $i < $length-1; $i++) {
 $xvar1 =  $xvar1 . $var1[$i] . "|" ;
}
$xvar1 =  $xvar1 . $var1[$i] ;

/////////

$url = explode("?",$url); 
$url = $url['0']; 


//echo  " { url :" . $url . "}<br>";
//echo  " { title :" . $title . "}<br>";
//echo  " { price :" . $price. "}<br>";
 foreach($html->find('span[class="percent-num"]') as $a) {
//echo  " { Rating :" .  $a->plaintext . "}<br>";
}

 foreach($html->find('span[class="order-num"]') as $a) {
//echo  " { Orders:" .  $a->plaintext . "}<br>";
}




//echo  " { variation 1 :" . $xvar1 . "}<br>";



$length = count($var2);
for ($i = 0; $i < $length-1; $i++) {
 $xvar2 =  $xvar2. $var2[$i] . "|" ;
}
$xvar2 =  $xvar2 . $var2[$i] ;

//echo  " { variation 2 :" . $xvar2 . "}<br>";



$length = count($shipd);
for ($i = 0; $i < $length; $i++) {
  $description .=  $shipd[$i] . "<br>" ;
}


foreach($html->find('li[class="property-item"]') as $a) {
//echo  " {" .  $a->plaintext . "}<br>";
}
 
 
 //echo "<br><br>{ variation Pictures  : <br>" ;
 
$length = count($var1);
for ($i = 0; $i < $length; $i++) {

$temp = 'img[title="' . $var1[$i] .'"]' ;
 foreach($html->find($temp) as $a) {
//echo  " { $var1[$i] : " .  $a->bigpic . "}<br>";
} 
}


//echo " } " ;



	$post = array(
        'post_author'  => 1,
        'post_content' => $description,
        'post_status'  => 'alib_imported',
        'post_title'   => $title,
        'post_parent'  => '',
        'post_type'    => 'product'
    );

    $post_id = wp_insert_post($post);
	
	wp_set_object_terms ($post_id,'variable','product_type');
	
	update_post_meta( $post_id,'_sku','');
    update_post_meta( $post_id,'_visibility','visible');
	update_post_meta($post_id, '_price', $price);
	update_post_meta($post_id, 'external_id', $product_id);
    update_post_meta($post_id, '_regular_price', $price);
	update_post_meta($post_id, '_stock_status', 'instock');
	update_post_meta($post_id, '_stock', 100);
	update_post_meta($post_id, 'ali_url', $url);
	
	
	$upload_dir = wp_upload_dir();
    $image_data = file_get_contents($product_img);
    $filename = basename($product_img);
    if(wp_mkdir_p($upload_dir['path']))     $file = $upload_dir['path'] . '/' . $filename;
    else                                    $file = $upload_dir['basedir'] . '/' . $filename;
    file_put_contents($file, $image_data);

    $wp_filetype = wp_check_filetype($filename, null );
    $attachment = array(
		'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
    $res2= set_post_thumbnail( $post_id, $attach_id );
	
//echo 'hello';

echo 'done';

die;
}

add_action('wp_ajax_alib_import_to_list', 'alib_import_to_list');
add_action('wp_ajax_nopriv_alib_import_to_list', 'alib_import_to_list');



//alib_push_to_shop_sn
add_action('wp_ajax_alib_push_to_shop_sn', 'alib_push_to_shop_sn');
add_action('wp_ajax_nopriv_alib_push_to_shop_sn', 'alib_push_to_shop_sn');
function alib_push_to_shop_sn(){
	
	$product_id = $_POST['product_id'];
	 $my_post = array(
        'ID'           => $product_id,
        'post_status'  => 'publish'
	 );

	// Update the post into the database
    $a = wp_update_post( $my_post );
     if($a){
		 echo 'done';
	 }
die;
}


//alib_import_delete_sn
add_action('wp_ajax_alib_import_delete_sn', 'alib_import_delete_sn');
add_action('wp_ajax_nopriv_alib_import_delete_sn', 'alib_import_delete_sn');
function alib_import_delete_sn(){
	
	$product_id = $_POST['product_id'];
	 
    $a = wp_delete_post( $product_id );
     if($a){
		 echo 'done';
	 }
die;
}

?>
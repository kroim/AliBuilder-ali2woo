<?php
    return array(
        array(
            'id' => 3,
            'name' => 'Apparel & Accessories'
        ),
        array(
            'id' => 34,
            'name' => 'Automobiles & Motorcycles'
        ),
	array(
            'id' => 1501,
            'name' => 'Baby Products'
        ),
	array(
            'id' => 66,
            'name' => 'Beauty & Health'
        ),
	array(
            'id' => 7,
            'name' => 'Computer & Networking'
        ),
	array(
            'id' => 13,
            'name' => 'Construction & Real Estate'
        ),
	array(
            'id' => 44,
            'name' => 'Consumer Electronics'
        ),
	array(
            'id' => 100008578,
            'name' => 'Customized Products'
        ),
	array(
            'id' => 5,
            'name' => 'Electrical Equipment & Supplies'
        ),
        array(
            'id' => 502,
            'name' => 'Electronic Components & Supplies'
        ),
	array(
            'id' => 2,
            'name' => 'Food'
        ),
        array(
            'id' => 1503,
            'name' => 'Furniture'
        ),
	array(
            'id' => 200003655,
            'name' => 'Hair & Accessories'
        ),
        array(
            'id' => 42,
            'name' => 'Hardware'
        ),
	array(
            'id' => 15,
            'name' => 'Home & Garden'
        ),
	array(
            'id' => 6,
            'name' => 'Home Appliances'
        ),
	array(
            'id' => 200003590,
            'name' => 'Industry & Business'
        ),
	array(
            'id' => 36,
            'name' => 'Jewelry & Watch'
        ),
        array(
            'id' => 39,
            'name' => 'Lights & Lighting'
        ),
	array(
            'id' => 1524,
            'name' => 'Luggage & Bags'
        ),
	array(
            'id' => 21,
            'name' => 'Office & School Supplies'
        ),
	array(
            'id' => 509,
            'name' => 'Phones & Telecommunications'
        ),
        array(
            'id' => 30,
            'name' => 'Security & Protection'
        ),
	array(
            'id' => 322,
            'name' => 'Shoes'
        ),
	array(
            'id' => 200001075,
            'name' => 'Special Category'
        ),
	array(
            'id' => 18,
            'name' => 'Sports & Entertainment'
        ),
	array(
            'id' => 1420,
            'name' => 'Tools'
        ),
        array(
            'id' => 26,
            'name' => 'Toys & Hobbies'
        ),
	array(
            'id' => 1511,
            'name' => 'Watches'
        ),
    );
    
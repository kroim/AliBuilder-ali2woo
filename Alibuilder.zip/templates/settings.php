<?php

	if(isset($_POST['save_settings'])){
		$api_key = $_POST['api_key'];
		$tracking_id = $_POST['tracking_id'];
		$language = $_POST['language'];
		$currency = $_POST['currency'];
		update_option('ali_api_key', $api_key, true);
		update_option('ali_tracking_id', $tracking_id, true);
		update_option('ali_language', $language, true);
		update_option('ali_currency', $currency, true);
	}

	$api_key = get_option('ali_api_key');
	$ali_tracking_id = get_option('ali_tracking_id');
	$ali_language = get_option('ali_language');
	$ali_currency = get_option('ali_currency'); 
	 
?>
<div class="wrap">
<h1 class="wp-heading-inline">Settings</h1>

</div>

<div style="width:95%;margin-top:25px;">


	
<div id="tabs">
  <ul>
    <li><a href="#tabs-1">General</a></li>
    <li><a href="#tabs-2">Pricing</a></li>
    <li><a href="#tabs-3">Payments</a></li>
  </ul>
  <div id="tabs-1">
    <p>
		<form method="post" action="">
		<table class="widefat gnrl_settings" style="max-width:400px;">
			<thead>
				<tr>
					<th colspan="2">General Settings</th>
				</tr>
			</thead>
			<thead>
				<tr>
					<th>API Key</th>
					<td><input type="text" name="api_key" value="<?php echo $api_key; ?>"></td>
				</tr>
				<tr>
					<th>Tracking Id</th>
					<td><input type="text" name="tracking_id" value="<?php echo $ali_tracking_id; ?>" ></td>
				</tr>
				<tr>
					<th>Language</th>
					<td>
						<select name="language" id="" class="">
							<option value="">--Select Language--</option>
                            <option value="en" <?php  if($ali_language=='en'){ echo 'selected="selected"'; } ?>>English</option>
                            <option value="ar" <?php  if($ali_language=='ar'){ echo 'selected="selected"'; } ?>>Arabic</option>
                            <option value="de" <?php  if($ali_language=='de'){ echo 'selected="selected"'; } ?>>German</option>
                            <option value="es" <?php  if($ali_language=='es'){ echo 'selected="selected"'; } ?>>Spanish</option>
                            <option value="fr" <?php  if($ali_language=='fr'){ echo 'selected="selected"'; } ?>>French</option>
                            <option value="it" <?php  if($ali_language=='it'){ echo 'selected="selected"'; } ?>>Italian</option>
                            <option value="pl" <?php  if($ali_language=='pl'){ echo 'selected="selected"'; } ?>>Polish</option>
                            <option value="ja" <?php  if($ali_language=='ja'){ echo 'selected="selected"'; } ?>>Japanese</option>
                            <option value="ko" <?php  if($ali_language=='ko'){ echo 'selected="selected"'; } ?>>Korean</option>
                            <option value="nl" <?php  if($ali_language=='nl'){ echo 'selected="selected"'; } ?>>Notherlandish (Dutch)</option>
                            <option value="pt" <?php  if($ali_language=='pt'){ echo 'selected="selected"'; } ?>>Portuguese (Brasil)</option>
                            <option value="ru" <?php  if($ali_language=='ru'){ echo 'selected="selected"'; } ?>>Russian</option>
                            <option value="th" <?php  if($ali_language=='th'){ echo 'selected="selected"'; } ?>>Thai</option>    
                            <option value="id" <?php  if($ali_language=='id'){ echo 'selected="selected"'; } ?>>Indonesian</option>              
                            <option value="tr" <?php  if($ali_language=='tr'){ echo 'selected="selected"'; } ?>>Turkish</option>
                            <option value="vi" <?php  if($ali_language=='vi'){ echo 'selected="selected"'; } ?>>Vietnamese</option>
                        </select>
					</td>
				</tr>
				<tr>
					<th>Currency</th>
					<td>
						<select name="currency" id="" class="">
                            <option value="">--Select Currency--</option>
                            <option value="usd" <?php  if($ali_currency=='usd'){ echo 'selected="selected"'; } ?>>USD</option>
                            <option value="rub" <?php  if($ali_currency=='rub'){ echo 'selected="selected"'; } ?>>RUB</option>
                            <option value="gbp" <?php  if($ali_currency=='gbp'){ echo 'selected="selected"'; } ?>>GBP</option>
                            <option value="brl" <?php  if($ali_currency=='brl'){ echo 'selected="selected"'; } ?>>BRL</option> 
                            <option value="cad" <?php  if($ali_currency=='cad'){ echo 'selected="selected"'; } ?>>CAD</option>
                            <option value="aud" <?php  if($ali_currency=='aud'){ echo 'selected="selected"'; } ?>>AUD</option>
                            <option value="eur" <?php  if($ali_currency=='eur'){ echo 'selected="selected"'; } ?>>EUR</option>
                            <option value="inr" <?php  if($ali_currency=='inr'){ echo 'selected="selected"'; } ?>>INR</option>
                            <option value="uah" <?php  if($ali_currency=='uah'){ echo 'selected="selected"'; } ?>>UAH</option>
                            <option value="jpy" <?php  if($ali_currency=='jpy'){ echo 'selected="selected"'; } ?>>JPY</option>
                            <option value="mxn" <?php  if($ali_currency=='mxn'){ echo 'selected="selected"'; } ?>>MXN</option>
                            <option value="idr" <?php  if($ali_currency=='idr'){ echo 'selected="selected"'; } ?>>IDR</option>
                            <option value="try" <?php  if($ali_currency=='try'){ echo 'selected="selected"'; } ?>>TRY</option>
                            <option value="sek" <?php  if($ali_currency=='sek'){ echo 'selected="selected"'; } ?>>SEK</option>
                        </select>
					</td>
				</tr>
				<tr>
					<td colspan="2"><input type="submit" name="save_settings" value="Save" class="button button-primary"/></td>
				</tr>
			</thead>
		</table>
		</form>
	</p>
  </div>
  <div id="tabs-2">
    <p>Morbi tincidunt, dui sit amet facilisis feugiat, odio metus gravida ante, ut pharetra massa metus id nunc. Duis scelerisque molestie turpis. Sed fringilla, massa eget luctus malesuada, metus eros molestie lectus, ut tempus eros massa ut dolor. Aenean aliquet fringilla sem. Suspendisse sed ligula in ligula suscipit aliquam. Praesent in eros vestibulum mi adipiscing adipiscing. Morbi facilisis. Curabitur ornare consequat nunc. Aenean vel metus. Ut posuere viverra nulla. Aliquam erat volutpat. Pellentesque convallis. Maecenas feugiat, tellus pellentesque pretium posuere, felis lorem euismod felis, eu ornare leo nisi vel felis. Mauris consectetur tortor et purus.</p>
  </div>
  <div id="tabs-3">
    <p>Mauris eleifend est et turpis. Duis id erat. Suspendisse potenti. Aliquam vulputate, pede vel vehicula accumsan, mi neque rutrum erat, eu congue orci lorem eget lorem. Vestibulum non ante. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce sodales. Quisque eu urna vel enim commodo pellentesque. Praesent eu risus hendrerit ligula tempus pretium. Curabitur lorem enim, pretium nec, feugiat nec, luctus a, lacus.</p>
    <p>Duis cursus. Maecenas ligula eros, blandit nec, pharetra at, semper at, magna. Nullam ac lacus. Nulla facilisi. Praesent viverra justo vitae neque. Praesent blandit adipiscing velit. Suspendisse potenti. Donec mattis, pede vel pharetra blandit, magna ligula faucibus eros, id euismod lacus dolor eget odio. Nam scelerisque. Donec non libero sed nulla mattis commodo. Ut sagittis. Donec nisi lectus, feugiat porttitor, tempor ac, tempor vitae, pede. Aenean vehicula velit eu tellus interdum rutrum. Maecenas commodo. Pellentesque nec elit. Fusce in lacus. Vivamus a libero vitae lectus hendrerit hendrerit.</p>
  </div>
</div>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script>
$(document).ready(function(){
	$( "#tabs" ).tabs();
});
</script>

<style>
  .gnrl_settings th{
	  font-weight: bold;
	  border-right: 1px solid #d4cece;
	  background: #efefef;
  }
  .gnrl_settings input, .gnrl_settings select{
	  width: 97%;
	  height: 26px;
  }
  </style>
  
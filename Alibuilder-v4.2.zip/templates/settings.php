<?php

	if(isset($_POST['save_acc_settings'])){
		//echo '<pre>'; print_r($_POST); exit;
		$api_key = $_POST['api_key'];
		$tracking_id = $_POST['tracking_id'];
		$language = $_POST['language'];
		$currency = $_POST['currency'];
		update_option('ali_api_key', $api_key, true);
		update_option('ali_tracking_id', $tracking_id, true);
		update_option('ali_language', $language, true);
		update_option('ali_currency', $currency, true);  
	
		$product_type = 'no';
		$product_status = 'no';
		$import_attr = 'no';
		$import_desc = 'no';
		$imp_img_desc = 'no';
		$external_img_url = 'no';
		$rand_stock_val = 'no';
		$aliexp_sync = 'no';
		$avlb_product_status = 'no';
		$sync_type = 'no';
		
		$product_type = $_POST['product_type'];
		$product_status = $_POST['product_status'];
		$import_attr = $_POST['import_attr'];
		$import_desc = $_POST['import_desc'];
		$imp_img_desc = $_POST['imp_img_desc'];
		$external_img_url = $_POST['external_img_url'];
		$rand_stock_val = $_POST['rand_stock_val'];
		$aliexp_sync = $_POST['aliexp_sync'];
		$avlb_product_status = $_POST['avlb_product_status'];
		$sync_type = $_POST['sync_type'];
		
		update_option('alib_product_type', $product_type, true);
		update_option('alib_product_status', $product_status, true);
		update_option('alib_import_attr', $import_attr, true);
		update_option('alib_import_desc', $import_desc, true);
		update_option('alib_imp_img_desc', $imp_img_desc, true);
		update_option('alib_external_img_url', $external_img_url, true);
		update_option('alib_rand_stock_val', $rand_stock_val, true);
		update_option('alib_aliexp_sync', $aliexp_sync, true);
		update_option('alib_avlb_product_status', $avlb_product_status, true);
		update_option('alib_sync_type', $sync_type, true);
		
	}
	
	$api_key = get_option('ali_api_key');
	$ali_tracking_id = get_option('ali_tracking_id');
	$ali_language = get_option('ali_language');
	$ali_currency = get_option('ali_currency'); 
	
	$alib_product_type = get_option('alib_product_type');
	$alib_product_status = get_option('alib_product_status');
	$alib_import_attr = get_option('alib_import_attr');
	$alib_import_desc = get_option('alib_import_desc');
	$alib_imp_img_desc = get_option('alib_imp_img_desc');
	$alib_external_img_url = get_option('alib_external_img_url');
	$alib_rand_stock_val = get_option('alib_rand_stock_val');
	$alib_aliexp_sync = get_option('alib_aliexp_sync');
	$alib_avlb_product_status = get_option('alib_avlb_product_status');
	$alib_sync_type = get_option('alib_sync_type');
	 
?>
<div class="wrap">
<h1 class="wp-heading-inline">Settings</h1>

</div>

<div style="width:95%;margin-top:25px;">



<div class="container1">
 <form method="post" action="">
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse1">General Settings&nbsp;<span class="glyphicon glyphicon-chevron-down" style="position:relative;left:7px;"></span></a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-footer">
			
				<p>
					
					<table class="widefat gnrl_settings" style="max-width:700px;">
						 
						<thead>
							<tr>
								<th>Default product type</th>
								<td>
									<select name="product_type" id="" class="form-control small-input">
										<option value="simple" <?php if($alib_product_type=='simple'){ echo 'selected="selected"'; } ?>>Simple/Variable Product</option>
										<option value="external" <?php if($alib_product_type=='external'){ echo 'selected="selected"'; } ?>>External/Affiliate Product</option>
									</select>
								</td>
							</tr>
							<tr>
								<th>Default product status</th>
								<td>
									<select name="product_status" id="" class="form-control small-input">
										<option value="publish" <?php if($alib_product_status=='publish'){ echo 'selected="selected"'; } ?>>Publish</option>
										<option value="draft" <?php if($alib_product_status=='draft'){ echo 'selected="selected"'; } ?>>Draft</option>
									</select>
								</td>
							</tr>
							<tr>
								<th>Not import attributes</th>
								<td>
									<input type="checkbox" class="form-control" id="" name="import_attr" value="yes" <?php if($alib_import_attr=='yes'){ echo 'checked="checked"'; } ?> >
								</td>
							</tr>
							<tr>
								<th>Not import description</th>
								<td>
									<input type="checkbox" class="form-control" id="" name="import_desc" value="yes" <?php if($alib_import_desc=='yes'){ echo 'checked="checked"'; } ?>>
								</td>
							</tr>
							<tr>
								<th>Don't import images from the description</th>
								<td>
									<input type="checkbox" class="form-control" id="" name="imp_img_desc" value="yes" <?php if($alib_imp_img_desc=='yes'){ echo 'checked="checked"'; } ?>>
								</td>
							</tr>
							<tr>
								<th>Use external image urls</th>
								<td>
									<input type="checkbox" class="form-control" id="" name="external_img_url" value="yes" <?php if($alib_external_img_url=='yes'){ echo 'checked="checked"'; } ?>>
								</td>
							</tr>
							<tr>
								<th>Use random stock value</th>
								<td>
									<input type="checkbox" class="form-control" id="" name="rand_stock_val" value="yes" <?php if($alib_rand_stock_val=='yes'){ echo 'checked="checked"'; } ?>>
								</td>
							</tr>
							<tr>
								<td colspan="2">Schedule Settings</th>
								
							</tr>
							<tr>
								<th>Aliexpress Sync </th>
								<td>
									<input type="checkbox" class="form-control" id="" name="aliexp_sync" value="yes" <?php if($alib_aliexp_sync=='yes'){ echo 'checked="checked"'; } ?>>
								</td>
							</tr>
							<tr>
								<th>Not available product status</th>
								<td>
									<select class="form-control small-input" name="avlb_product_status" id="">
										<option value="trash">Trash</option>
										<option value="outofstock" <?php if($alib_avlb_product_status=='outofstock'){ echo 'selected="selected"'; } ?>>Out of stock</option>
										<option value="instock" <?php if($alib_avlb_product_status=='instock'){ echo 'selected="selected"'; } ?>>In stock</option>
									</select>
								</td>
							</tr>
							<tr>
								<th>Synchronization type</th>
								<td>
									<select class="form-control small-input" name="sync_type" id="">
										<option value="price_and_stock"  <?php if($alib_sync_type=='price_and_stock'){ echo 'selected="selected"'; } ?>>Sync price and stock</option>
										<option value="price"  <?php if($alib_sync_type=='price'){ echo 'selected="selected"'; } ?>>Sync only price</option>
										<option value="stock"  <?php if($alib_sync_type=='stock'){ echo 'selected="selected"'; } ?>>Sync only stock</option>
										<option value="no"  <?php if($alib_sync_type=='no'){ echo 'selected="selected"'; } ?>>Don't sync prices and stock</option>
									</select>
								</td>
							</tr>
							 
						</thead>
					</table>
					 
				</p>
	</div>
      </div>
    </div>
  </div>
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse2">Account Settings<span class="glyphicon glyphicon-chevron-down" style="position: relative;top: 3px;left: 9px;"></span></a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-footer">
			 
		<table class="widefat gnrl_settings" style="max-width:400px;">
			 
			<thead>
				<tr>
					<th>APP Key</th>
					<td><input type="text" name="api_key" value="<?php echo $api_key; ?>"></td>
				</tr>
				<tr>
					<th>Tracking Id</th>
					<td><input type="text" name="tracking_id" value="<?php echo $ali_tracking_id; ?>" ></td>
				</tr>
				<tr>
					<th>Use Custom account</th>
					<td><input type="text" name="" value=""></td>
				</tr>
				<tr>
					<th>Account Type</th>
					<td><input type="text" name="" value="" ></td>
				</tr>
				<tr>

					<th>Language</th>
					<td>
						<select name="language" id="" class="">
							<option value="">--Select Language--</option>
                            <option value="en" <?php  if($ali_language=='en'){ echo 'selected="selected"'; } ?>>English</option>
                            <option value="ar" <?php  if($ali_language=='ar'){ echo 'selected="selected"'; } ?>>Arabic</option>
                            <option value="de" <?php  if($ali_language=='de'){ echo 'selected="selected"'; } ?>>German</option>
                            <option value="es" <?php  if($ali_language=='es'){ echo 'selected="selected"'; } ?>>Spanish</option>
                            <option value="fr" <?php  if($ali_language=='fr'){ echo 'selected="selected"'; } ?>>French</option>
                            <option value="it" <?php  if($ali_language=='it'){ echo 'selected="selected"'; } ?>>Italian</option>
                            <option value="pl" <?php  if($ali_language=='pl'){ echo 'selected="selected"'; } ?>>Polish</option>
                            <option value="ja" <?php  if($ali_language=='ja'){ echo 'selected="selected"'; } ?>>Japanese</option>
                            <option value="ko" <?php  if($ali_language=='ko'){ echo 'selected="selected"'; } ?>>Korean</option>
                            <option value="nl" <?php  if($ali_language=='nl'){ echo 'selected="selected"'; } ?>>Notherlandish (Dutch)</option>
                            <option value="pt" <?php  if($ali_language=='pt'){ echo 'selected="selected"'; } ?>>Portuguese (Brasil)</option>
                            <option value="ru" <?php  if($ali_language=='ru'){ echo 'selected="selected"'; } ?>>Russian</option>
                            <option value="th" <?php  if($ali_language=='th'){ echo 'selected="selected"'; } ?>>Thai</option>    
                            <option value="id" <?php  if($ali_language=='id'){ echo 'selected="selected"'; } ?>>Indonesian</option>              
                            <option value="tr" <?php  if($ali_language=='tr'){ echo 'selected="selected"'; } ?>>Turkish</option>
                            <option value="vi" <?php  if($ali_language=='vi'){ echo 'selected="selected"'; } ?>>Vietnamese</option>
                        </select>
					</td>
				</tr>
				<tr>
					<th>Currency</th>
					<td>
						<select name="currency" id="" class="">
                            <option value="">--Select Currency--</option>
                            <option value="usd" <?php  if($ali_currency=='usd'){ echo 'selected="selected"'; } ?>>USD</option>
                            <option value="rub" <?php  if($ali_currency=='rub'){ echo 'selected="selected"'; } ?>>RUB</option>
                            <option value="gbp" <?php  if($ali_currency=='gbp'){ echo 'selected="selected"'; } ?>>GBP</option>
                            <option value="brl" <?php  if($ali_currency=='brl'){ echo 'selected="selected"'; } ?>>BRL</option> 
                            <option value="cad" <?php  if($ali_currency=='cad'){ echo 'selected="selected"'; } ?>>CAD</option>
                            <option value="aud" <?php  if($ali_currency=='aud'){ echo 'selected="selected"'; } ?>>AUD</option>
                            <option value="eur" <?php  if($ali_currency=='eur'){ echo 'selected="selected"'; } ?>>EUR</option>
                            <option value="inr" <?php  if($ali_currency=='inr'){ echo 'selected="selected"'; } ?>>INR</option>
                            <option value="uah" <?php  if($ali_currency=='uah'){ echo 'selected="selected"'; } ?>>UAH</option>
                            <option value="jpy" <?php  if($ali_currency=='jpy'){ echo 'selected="selected"'; } ?>>JPY</option>
                            <option value="mxn" <?php  if($ali_currency=='mxn'){ echo 'selected="selected"'; } ?>>MXN</option>
                            <option value="idr" <?php  if($ali_currency=='idr'){ echo 'selected="selected"'; } ?>>IDR</option>
                            <option value="try" <?php  if($ali_currency=='try'){ echo 'selected="selected"'; } ?>>TRY</option>
                            <option value="sek" <?php  if($ali_currency=='sek'){ echo 'selected="selected"'; } ?>>SEK</option>
                        </select>
					</td>
				</tr>
				
			</thead>
		</table>
		 
	</div>
      </div>
    </div>
  </div>
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse3">Pricing Settings<span class="glyphicon glyphicon-chevron-down" style="position: relative;top: 3px;left: 19px;"></span></a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">Panel Body</div>
        <div class="panel-footer">Panel Footer</div>
      </div>
    </div>
  </div>
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse4">Reviews Settings<span class="glyphicon glyphicon-chevron-down" style="position: relative;top: 3px;left: 9px;"></span></a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">Panel Body</div>
        <div class="panel-footer">Panel Footer</div>
      </div>
    </div>
  </div>
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse5">Shipping Settings<span class="glyphicon glyphicon-chevron-down" style="position: relative;top: 3px;left: 9px;"></span></a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-footer">
			 
		<table class="widefat gnrl_settings" style="max-width:400px;">
			 
			<thead>
				<tr>
					<th>Use Aliexpress Shipping</th>
					<td><input type="text" name="use_alip_ship" value=""></td>
				</tr>
				<tr>
					<th>Default Shipping Country</th>
					<td><input type="text" name="def_ship_cntry" value="" ></td>
				</tr>
				 
				</thead>
		</table>
		 
	</div>
      </div>
    </div>
  </div>
  
  <div class="panel-group">
    <div class="panel panel-warning">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" href="#collapse6">System Info<span class="glyphicon glyphicon-chevron-down" style="position: relative;top: 3px;left: 48px;"></span></a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="panel-footer">
			<table class="widefat gnrl_settings" style="max-width:400px;">
			 
			<thead>
				<tr>
					<th>Server address</th>
					<td><?php echo $_SERVER['SERVER_ADDR']; ?></td>
				</tr>
				<tr>
					<th>Php version</th>
					<td style="color:green">OK</td>
				</tr>  
				<tr>
					<th>Server ping</th>
					<td style="color:green">OK</td>
				</tr>
				</thead>
		</table>
	</div>
      </div>
    </div>
  </div>
  <div>
					<input type="submit" name="save_acc_settings" value="Update Settings" class="btn btn-success"/>
				 </div>
  </form>
</div>
    
				
				
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	$( "#tabs" ).tabs();
});
</script>

<style>
  .gnrl_settings th{
	  font-weight: bold;
	  border-right: 1px solid #d4cece;
	  background: #efefef;
  }
  .gnrl_settings input, .gnrl_settings select{
	  width: 97%;
	  height: 26px;
  }
  </style>
  
<div class="wrap">
<h1 class="wp-heading-inline">Settings</h1>

</div>

<div style="width:95%;margin-top:25px;">

<h2>Save time adding and ordering products by using our Chrome Extension!&nbsp;<a href="#" class="button button-primary">Get Chrome Extension</a></h2>
</div>
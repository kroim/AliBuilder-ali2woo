<?php
    
define("APP_KEY", "*****");
define("APP_SECRET", "********");
